import { useState } from 'react';
import { StyleSheet, Text, View, TouchableOpacity, StatusBar, ScrollView, Alert, TextInput } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';

const STORAGE_KEY = 'almaydan_categories';

export default function ImportScreen({ onBack }) {
  const [jsonText, setJsonText] = useState('');
  const [preview, setPreview] = useState(null);
  const [imported, setImported] = useState(false);

  const handleParseJSON = () => {
    try {
      const data = JSON.parse(jsonText);
      if (!Array.isArray(data)) {
        Alert.alert('خطأ', 'البيانات يجب أن تكون مصفوفة');
        return;
      }
      setPreview(data);
    } catch (e) {
      Alert.alert('خطأ', 'البيانات غير صحيحة — تأكد من تنسيق JSON');
    }
  };

  const handleImport = async () => {
    if (!preview) return;

    try {
      const existing = await AsyncStorage.getItem(STORAGE_KEY);
      const existingCats = existing ? JSON.parse(existing) : [];

      preview.forEach((row) => {
        const catName = row['الفئة'] || row['category'] || 'غير محدد';
        const catEmoji = row['ايموجي'] || row['emoji'] || '📁';
        const question = row['السؤال'] || row['question'] || '';
        const answer = row['الجواب'] || row['answer'] || '';
        const difficulty = parseInt(row['الصعوبة'] || row['difficulty'] || 100);

        if (!question || !answer) return;

        // ابحث عن الفئة الموجودة
        const existingCat = existingCats.find(c => c.name === catName);

        if (existingCat) {
          // أضف للفئة الموجودة
          existingCat.questions.push({
            id: Date.now().toString() + Math.random().toString(36).substr(2, 9),
            text: question,
            answer: answer,
            difficulty: difficulty,
          });
        } else {
          // أنشئ فئة جديدة
          existingCats.push({
            id: Date.now().toString() + Math.random().toString(36).substr(2, 9),
            name: catName,
            emoji: catEmoji,
            image: null,
            questions: [{
              id: Date.now().toString() + Math.random().toString(36).substr(2, 9),
              text: question,
              answer: answer,
              difficulty: difficulty,
            }],
          });
        }
      });

      await AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(existingCats));
      setImported(true);
      Alert.alert('✅ تم', `تم استيراد ${preview.length} سؤال بنجاح!`);
    } catch (e) {
      Alert.alert('خطأ', 'حدث خطأ في الاستيراد');
    }
  };

  return (
    <ScrollView contentContainerStyle={styles.container}>
      <StatusBar barStyle="light-content" backgroundColor="#0d0d2b" />

      <View style={styles.header}>
        <TouchableOpacity onPress={onBack} style={styles.backBtn}>
          <Text style={styles.backText}>→ رجوع</Text>
        </TouchableOpacity>
        <Text style={styles.title}>📥 استيراد أسئلة</Text>
        <View style={{ width: 60 }} />
      </View>

      <View style={styles.instructBox}>
        <Text style={styles.instructTitle}>📋 طريقة الاستيراد:</Text>
        <Text style={styles.instructText}>الصق بيانات JSON هنا بهذا التنسيق:</Text>
        <Text style={styles.codeText}>{`[
  {
    "الفئة": "أفلام",
    "ايموجي": "🎬",
    "السؤال": "من أخرج Titanic؟",
    "الجواب": "جيمس كاميرون",
    "الصعوبة": 300
  }
]`}</Text>
        <Text style={styles.instructNote}>
          ✅ إذا كانت الفئة موجودة ستُضاف الأسئلة إليها تلقائياً
        </Text>
      </View>

      <TextInput
        style={styles.jsonInput}
        placeholder="الصق بيانات JSON هنا..."
        placeholderTextColor="#555577"
        value={jsonText}
        onChangeText={setJsonText}
        multiline
        numberOfLines={8}
        textAlign="right"
        textAlignVertical="top"
      />

      <TouchableOpacity style={styles.parseBtn} onPress={handleParseJSON}>
        <Text style={styles.parseBtnText}>🔍 معاينة البيانات</Text>
      </TouchableOpacity>

      {preview && (
        <View style={styles.previewBox}>
          <Text style={styles.previewTitle}>✅ تم قراءة {preview.length} سجل</Text>
          <Text style={styles.previewSample}>عينة:</Text>
          {preview.slice(0, 3).map((row, i) => (
            <View key={i} style={styles.previewRow}>
              <Text style={styles.previewCat}>{row['الفئة'] || row['category']}</Text>
              <Text style={styles.previewQ} numberOfLines={1}>{row['السؤال'] || row['question']}</Text>
              <Text style={styles.previewA} numberOfLines={1}>✅ {row['الجواب'] || row['answer']}</Text>
            </View>
          ))}

          {!imported && (
            <TouchableOpacity style={styles.importBtn} onPress={handleImport}>
              <Text style={styles.importBtnText}>💾 استيراد الكل ({preview.length} سجل)</Text>
            </TouchableOpacity>
          )}

          {imported && (
            <View style={styles.successBox}>
              <Text style={styles.successText}>🎉 تم الاستيراد بنجاح!</Text>
              <TouchableOpacity style={styles.backBtn2} onPress={onBack}>
                <Text style={styles.backBtn2Text}>← العودة للوحة الإدارة</Text>
              </TouchableOpacity>
            </View>
          )}
        </View>
      )}

    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flexGrow: 1,
    backgroundColor: '#0d0d2b',
    paddingHorizontal: 24,
    paddingVertical: 50,
    gap: 24,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  backBtn: { padding: 8 },
  backText: { color: '#f5c518', fontSize: 16, fontWeight: '700' },
  title: { fontSize: 20, fontWeight: '900', color: '#f5c518' },
  instructBox: {
    backgroundColor: '#1a1a3e',
    borderRadius: 16,
    padding: 16,
    gap: 10,
    borderWidth: 1,
    borderColor: '#f5c51833',
  },
  instructTitle: { color: '#f5c518', fontSize: 16, fontWeight: '800' },
  instructText: { color: '#a09060', fontSize: 14 },
  codeText: {
    color: '#4aff4a',
    fontSize: 12,
    fontFamily: 'monospace',
    backgroundColor: '#0d0d2b',
    padding: 10,
    borderRadius: 8,
  },
  instructNote: { color: '#4aff4a', fontSize: 13, fontWeight: '600' },
  jsonInput: {
    backgroundColor: '#1a1a3e',
    borderWidth: 1.5,
    borderColor: '#2a2a55',
    borderRadius: 14,
    paddingHorizontal: 16,
    paddingVertical: 14,
    color: '#ffffff',
    fontSize: 13,
    minHeight: 150,
  },
  parseBtn: {
    backgroundColor: '#f5c518',
    paddingVertical: 16,
    borderRadius: 16,
    alignItems: 'center',
    elevation: 8,
  },
  parseBtnText: { color: '#0d0d2b', fontSize: 17, fontWeight: '800' },
  previewBox: {
    backgroundColor: '#1a1a3e',
    borderRadius: 16,
    padding: 16,
    gap: 12,
    borderWidth: 1,
    borderColor: '#2a5a2a',
  },
  previewTitle: { color: '#4aff4a', fontSize: 16, fontWeight: '800' },
  previewSample: { color: '#a09060', fontSize: 13 },
  previewRow: {
    backgroundColor: '#0d0d2b',
    borderRadius: 10,
    padding: 10,
    gap: 4,
  },
  previewCat: { color: '#f5c518', fontSize: 13, fontWeight: '700' },
  previewQ: { color: '#ffffff', fontSize: 13 },
  previewA: { color: '#4aff4a', fontSize: 12 },
  importBtn: {
    backgroundColor: '#1a5a3a',
    paddingVertical: 16,
    borderRadius: 14,
    alignItems: 'center',
    borderWidth: 1.5,
    borderColor: '#2a8a5a',
  },
  importBtnText: { color: '#ffffff', fontSize: 17, fontWeight: '800' },
  successBox: { alignItems: 'center', gap: 12 },
  successText: { color: '#4aff4a', fontSize: 18, fontWeight: '900' },
  backBtn2: {
    backgroundColor: '#f5c518',
    paddingVertical: 14,
    paddingHorizontal: 24,
    borderRadius: 14,
    alignItems: 'center',
  },
  backBtn2Text: { color: '#0d0d2b', fontSize: 16, fontWeight: '800' },
});